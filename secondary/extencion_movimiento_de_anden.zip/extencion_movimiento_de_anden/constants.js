const modalReceiptContainerId = "myModalShowTable";
const buttonReceiptContainerId = "openModalBtn";

const nameStorageContainer = "dataContainerMovimientoDeAnden";
const eventNameStorgageChange = "dataContainersReceiptChange";

// Objeto Para Almacenar los datos de los contenedores
const interfaceStorage = {
	receiptType: "string",
	dataContainer: "array",
	trailerId: "string - optional",
};
