function inicio() {
  const putawayGroup = document.querySelector('#proRfWrapper > h3') ?? undefined;

  if (!putawayGroup) return;

  if (putawayGroup.innerHTML === 'Putaway group') {
    const tdInput = document.querySelector(
      '#proRfWrapper > form > table > tbody > tr:nth-child(1) > td:nth-child(2)'
    );

    if (tdInput) {
      const content = tdInput.childNodes[0].nodeValue.trim().replace(/&nbsp;/g, '');

      console.log(content);
      const result = content.replace(/-$/, '');

      if (result.includes('#-')) return;

      Form1.GROUPID.value = result;
    }
  }
}

window.addEventListener('load', inicio, { once: true });
