function inicio() {
  console.log('[receiptLineInsight.js]');
}

window.addEventListener('load', inicio, { once: true });
